Additional Credits
==

CloudCompare uses many other open source and Creative Commons licensed materials. We are grateful to the creators of these works!

Icons
--
**monitor.svg**
- Created by [Vectors Market](https://www.flaticon.com/authors/vectors-market) and licensed under [Creative Commons 3.0 BY](https://creativecommons.org/licenses/by/3.0/)
- Modified by [Andy Maloney](https://asmaloney.com)

**photo-camera.svg**
- Created by [Smashicons](https://www.flaticon.com/authors/smashicons) and licensed under [Creative Commons 3.0 BY](https://creativecommons.org/licenses/by/3.0/)
- Modified by [Andy Maloney](https://asmaloney.com)

**search.svg**

- Created by [DinosoftLabs](https://www.flaticon.com/authors/dinosoftlabs) and licensed under [Creative Commons 3.0 BY](https://creativecommons.org/licenses/by/3.0/)
- Modified by [Andy Maloney](https://asmaloney.com)